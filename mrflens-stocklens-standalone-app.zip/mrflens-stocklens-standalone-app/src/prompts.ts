import type { ResearchPack } from "./schemas.js";

/**
 * This is a compact application version of the Mr.FLENS Stock-LENS operating file.
 * Keep the longer source-of-truth file in your product docs and update this text when it changes.
 */
export const STOCK_LENS_SYSTEM = `
You are Mr.FLENS Stock-LENS Deep Dive: an institutional equity research analyst, financial modeller, and premium fintech one-page report generator.

Core output: a branded Stock-LENS one-page editorial infographic for public-company stocks.
Tone: sharp, concise, institutional, evidence-led, neutral. Do not hype. Do not say buy, sell, or hold. Phrase outputs as candidate screening, scenario framing, and risk-aware analysis.

Every ticker/company plus horizon is treated as a request to build a Stock-LENS A4 portrait one-pager.
Default investor profile: moderate risk tolerance, 3–5 year horizon. If the user provides a horizon, use it exactly.
For "PL", use Planet Labs PBC once current market data confirms it; flag only genuine ticker ambiguity.

Current-data rule:
Before producing any analysis or one-pager content, retrieve current live information from credible sources and cross-check key figures wherever practical.
Use company investor relations, SEC filings, earnings releases, exchange or quote data, reputable market-data providers, major financial/news sources, analyst/consensus providers where accessible, short-interest/ownership sources where accessible, and reputable sector/macro sources.
For reported financials prefer company filings/IR. For price/market data prefer exchange or reputable market-data providers. For consensus prefer reputable consensus providers. For short interest prefer official or reputable short-interest sources. For news/catalysts prefer major financial publications or company releases.
Never fabricate, guess, use stale example values, or fill standard public-company fields with N/A when a verified alternative exists.

One-pager required wording:
Header: "Mr.FLENS Stock-LENS DEEPDIVE"
Company line: "[Company Name] ([Ticker])"
Thesis line: "Why it screens as a strong [time-window] candidate"
Scenario note: "Scenario assumptions, not facts."
Scenario reaction note: "Scenario reactions are illustrative assumptions, not forecasts."
Compliance footer: "Informational only — not investment advice."

Required sections:
1. Header with title, company/ticker, thesis line, kicker, and data date
2. Hero metric cards
3. Why this stock made the screen
4. Stock-LENS Catalyst Map
5. What the market is watching
6. Street expectations / consensus snapshot
7. Big picture context
8. Stock-LENS Bull / Base / Bear scenarios
9. Main risks
10. Plain-English takeaway
11. Sources footer
12. Compliance footer

Image prompt must include:
"Use only the current data provided in this prompt. Do not use outdated example numbers, prior one-pager figures, placeholder values, stale dates, or invented data. Preserve the supplied figures and dates exactly."

Educational and informational only. Not investment advice. Not a recommendation to buy, sell, or hold any security.
`.trim();

export function buildResearchInstruction(query: string): string {
  return `
User request: ${query}

Create a current-source, cross-checked research pack for a Mr.FLENS Stock-LENS one-page infographic.

Required process:
1. Resolve the company/ticker/horizon.
2. Retrieve current market data and label it as intraday or latest close.
3. Retrieve latest filings/results/earnings-release context.
4. Retrieve consensus/analyst context where credible and accessible. If not accessible, use a verified alternative such as company guidance, analyst-rating summary, or recent reported quarter.
5. Retrieve short interest/ownership/insider context where credible and relevant. If not accessible, use a verified alternative.
6. Retrieve recent catalysts/news.
7. Retrieve peer/sector/macro context.
8. Cross-check material figures. Every hero metric must include source names.
9. Do not use N/A as a shortcut. Replace unverifiable metrics with verified alternatives.
10. Return only the structured research pack matching the provided schema.

Current date context for data labels: ${new Date().toISOString()}.
Use source names and URLs when available. Include verification notes describing key cross-checks and any unavailable data category.
`.trim();
}

function bulletList(items: string[]) {
  return items.map((item) => `- ${item}`).join("\n");
}

function sourceFooter(pack: ResearchPack): string {
  return pack.sources
    .map((s) => s.name)
    .filter(Boolean)
    .filter((name, index, arr) => arr.indexOf(name) === index)
    .slice(0, 8)
    .join("; ");
}

export function buildImagePrompt(pack: ResearchPack): string {
  const heroMetrics = pack.heroMetrics
    .map((m) => `- ${m.label}: ${m.value} — ${m.context} (Sources: ${m.sourceNames.join(", ")})`)
    .join("\n");

  const why = pack.whyThisStockMadeTheScreen
    .map((x) => `- ${x.title}: ${x.text}${x.sourceNames.length ? ` (Sources: ${x.sourceNames.join(", ")})` : ""}`)
    .join("\n");

  const watching = pack.marketWatching
    .map((x) => `- ${x.title}: ${x.text}${x.sourceNames.length ? ` (Sources: ${x.sourceNames.join(", ")})` : ""}`)
    .join("\n");

  const consensus = pack.consensusSnapshot
    .map((x) => `- ${x.title}: ${x.text}${x.sourceNames.length ? ` (Sources: ${x.sourceNames.join(", ")})` : ""}`)
    .join("\n");

  const bigPicture = pack.bigPictureContext
    .map((x) => `- ${x.title}: ${x.text}${x.sourceNames.length ? ` (Sources: ${x.sourceNames.join(", ")})` : ""}`)
    .join("\n");

  return `
Create a premium editorial-style single-page infographic in A4 portrait format for “Mr.FLENS Stock-LENS DEEPDIVE”.

Subject:
${pack.companyName} (${pack.ticker})

Main headline:
“${pack.companyName} (${pack.ticker})”

Subheadline:
“Why it screens as a strong ${pack.horizon} candidate”

Data box:
“${pack.dataDateLabel}”
Market status:
“${pack.marketStatusLabel}”

Kicker line:
“${pack.kicker}”

Design style:
A4 portrait, dark charcoal / near-black background, premium institutional fintech editorial styling, subtle cyan and electric-blue gradients, cool grey/silver highlights, restrained green and red accents, clean grid layout, elegant icons, strong typographic hierarchy, highly legible text, modern institutional infographic aesthetic, crisp section cards, layered diagrams, central flow diagram, clean data visualization styling, no clutter, no hype, no meme styling, no retail-trader look. Target aesthetic: dark fintech terminal meets premium institutional magazine.

Critical data instruction:
Use only the current data provided in this prompt. Do not use outdated example numbers, prior one-pager figures, placeholder values, stale dates, or invented data. Preserve the supplied figures and dates exactly.

Required sections and content:

1. Hero metric cards
${heroMetrics}

2. Why ${pack.ticker} made the screen
${why}

3. Stock-LENS Catalyst Map
${pack.catalystMap.join(" → ")}

4. What the market is watching
${watching}

5. Street expectations / consensus snapshot
${consensus}

6. Big picture context
${bigPicture}

7. Stock-LENS Bull / Base / Bear

Bull case:
- Setup: ${pack.bullBaseBear.bull.setup}
- Key assumption: ${pack.bullBaseBear.bull.keyAssumption}
- Neutral implication: ${pack.bullBaseBear.bull.neutralImplication}

Base case:
- Setup: ${pack.bullBaseBear.base.setup}
- Key assumption: ${pack.bullBaseBear.base.keyAssumption}
- Neutral implication: ${pack.bullBaseBear.base.neutralImplication}

Bear case:
- Setup: ${pack.bullBaseBear.bear.setup}
- Key assumption: ${pack.bullBaseBear.bear.keyAssumption}
- Neutral implication: ${pack.bullBaseBear.bear.neutralImplication}

Display note:
“Scenario assumptions, not facts.”
“Scenario reactions are illustrative assumptions, not forecasts.”

8. Main risks
${bulletList(pack.mainRisks)}

9. Plain-English takeaway
${bulletList(pack.plainEnglishTakeaway)}

10. Sources footer
“Sources: ${sourceFooter(pack)}.”

11. Compliance footer
“Informational only — not investment advice.”

Make the final result look like a polished, publication-quality institutional stock infographic with excellent text rendering, strong visual clarity, clean spacing, and no fabricated data. Keep all text compact and readable on one page.
`.trim();
}
