import fs from "node:fs";
import path from "node:path";
import cors from "cors";
import express from "express";
import rateLimit from "express-rate-limit";
import helmet from "helmet";
import morgan from "morgan";
import { assertConfig, config, OUTPUT_DIR, PUBLIC_DIR, ROOT_DIR } from "./config.js";
import { createJob, getJob, listJobs } from "./jobStore.js";

assertConfig();
fs.mkdirSync(OUTPUT_DIR, { recursive: true });

const app = express();

app.use(helmet({
  crossOriginResourcePolicy: false,
}));
app.use(cors());
app.use(express.json({ limit: "1mb" }));
app.use(morgan(config.nodeEnv === "production" ? "combined" : "dev"));

app.use(
  "/api",
  rateLimit({
    windowMs: 60_000,
    limit: 20,
    standardHeaders: true,
    legacyHeaders: false,
  })
);

app.use("/", express.static(PUBLIC_DIR));
app.use("/outputs", express.static(OUTPUT_DIR));

app.get("/api/health", (_req, res) => {
  res.json({
    ok: true,
    service: "mrflens-stocklens-standalone-app",
    reasoningModel: config.reasoningModel,
    imageModel: config.imageModel,
  });
});

app.post("/api/jobs", (req, res) => {
  const query = typeof req.body?.query === "string" ? req.body.query.trim() : "";
  const makePdf = Boolean(req.body?.makePdf);

  if (!query) {
    return res.status(400).json({ error: "Missing query. Example: PL 3-5 yr" });
  }

  const job = createJob(query, makePdf);
  return res.status(202).json({ jobId: job.id, status: job.status });
});

app.get("/api/jobs", (_req, res) => {
  res.json({ jobs: listJobs() });
});

app.get("/api/jobs/:jobId", (req, res) => {
  const job = getJob(req.params.jobId);
  if (!job) return res.status(404).json({ error: "Job not found" });
  return res.json(job);
});

// Convenience fallback for browser refresh.
app.use((_req, res) => {
  res.sendFile(path.join(PUBLIC_DIR, "index.html"));
});

app.listen(config.port, () => {
  console.log(`Mr.FLENS Stock-LENS app running at http://localhost:${config.port}`);
  console.log(`Project root: ${ROOT_DIR}`);
});
