import "dotenv/config";
import path from "node:path";
import { fileURLToPath } from "node:url";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

export const ROOT_DIR = path.resolve(__dirname, "..");
export const PUBLIC_DIR = path.join(ROOT_DIR, "public");
export const OUTPUT_DIR = path.join(ROOT_DIR, "outputs");

export const config = {
  port: Number(process.env.PORT ?? 8787),
  openaiApiKey: process.env.OPENAI_API_KEY ?? process.env.OPEN_AI_API_KEY ?? "",
  reasoningModel: process.env.OPENAI_REASONING_MODEL ?? "gpt-5.5",
  imageModel: process.env.OPENAI_IMAGE_MODEL ?? "gpt-image-2",
  reasoningEffort: process.env.OPENAI_REASONING_EFFORT ?? "high",
  imageQuality: process.env.OPENAI_IMAGE_QUALITY ?? "high",
  imageSize: process.env.OPENAI_IMAGE_SIZE ?? "1024x1536",
  nodeEnv: process.env.NODE_ENV ?? "development",
};

export function assertConfig() {
  if (!config.openaiApiKey) {
    throw new Error(
      "Missing OPENAI_API_KEY. Add it to .env. The alias OPEN_AI_API_KEY is also accepted."
    );
  }
}
