import fs from "node:fs/promises";
import { PDFDocument } from "pdf-lib";

/**
 * Creates a simple one-page A4 PDF wrapper around the generated PNG.
 * The PNG remains the primary distinct one-pager deliverable.
 */
export async function createPdfFromPng(pngPath: string, pdfPath: string) {
  const pngBytes = await fs.readFile(pngPath);
  const pdfDoc = await PDFDocument.create();

  // A4 portrait in points.
  const page = pdfDoc.addPage([595.28, 841.89]);
  const png = await pdfDoc.embedPng(pngBytes);

  const pageWidth = page.getWidth();
  const pageHeight = page.getHeight();
  const margin = 18;

  const maxWidth = pageWidth - margin * 2;
  const maxHeight = pageHeight - margin * 2;
  const pngRatio = png.width / png.height;
  const boxRatio = maxWidth / maxHeight;

  let drawWidth = maxWidth;
  let drawHeight = maxHeight;

  if (pngRatio > boxRatio) {
    drawHeight = drawWidth / pngRatio;
  } else {
    drawWidth = drawHeight * pngRatio;
  }

  page.drawImage(png, {
    x: (pageWidth - drawWidth) / 2,
    y: (pageHeight - drawHeight) / 2,
    width: drawWidth,
    height: drawHeight,
  });

  const bytes = await pdfDoc.save();
  await fs.writeFile(pdfPath, bytes);
}
