import { z } from "zod";

export const SourceSchema = z.object({
  name: z.string().describe("Short source name, e.g. SEC, Nasdaq, Reuters, company IR."),
  url: z.string().describe("Source URL if available, otherwise an empty string."),
  sourceType: z
    .enum([
      "company_ir",
      "sec_filing",
      "exchange_or_quote",
      "market_data",
      "news",
      "consensus",
      "short_interest",
      "ownership",
      "sector_macro",
      "other",
    ])
    .describe("Source category."),
  checkedFor: z.array(z.string()).describe("Metrics or facts checked against this source."),
});

export const MetricSchema = z.object({
  label: z.string(),
  value: z.string(),
  context: z.string(),
  sourceNames: z.array(z.string()).min(1),
});

export const BulletWithSourcesSchema = z.object({
  title: z.string(),
  text: z.string(),
  sourceNames: z.array(z.string()).describe("Source names used for this bullet. Use an empty array only when the item is interpretive rather than factual."),
});

export const ScenarioSchema = z.object({
  setup: z.string(),
  keyAssumption: z.string(),
  neutralImplication: z.string(),
});

export const ResearchPackSchema = z.object({
  companyName: z.string(),
  ticker: z.string(),
  exchange: z.string().describe("Primary listing exchange or an empty string if unavailable."),
  horizon: z.string(),
  thesisLine: z.string(),
  kicker: z.string(),
  dataDateLabel: z.string(),
  marketStatusLabel: z.string(),
  heroMetrics: z.array(MetricSchema).min(4).max(6),
  whyThisStockMadeTheScreen: z.array(BulletWithSourcesSchema).min(3).max(3),
  catalystMap: z.array(z.string()).min(4).max(6),
  marketWatching: z.array(BulletWithSourcesSchema).min(4).max(4),
  consensusSnapshot: z.array(BulletWithSourcesSchema).min(3).max(5),
  bigPictureContext: z.array(BulletWithSourcesSchema).min(1).max(3),
  bullBaseBear: z.object({
    bull: ScenarioSchema,
    base: ScenarioSchema,
    bear: ScenarioSchema,
  }),
  mainRisks: z.array(z.string()).min(4).max(6),
  plainEnglishTakeaway: z.array(z.string()).min(3).max(3),
  sources: z.array(SourceSchema).min(3),
  verificationNotes: z.array(z.string()).min(1),
});

export type ResearchPack = z.infer<typeof ResearchPackSchema>;

export type StockLensJobStatus = "queued" | "running" | "complete" | "failed";

export type StockLensJob = {
  id: string;
  status: StockLensJobStatus;
  query: string;
  createdAt: string;
  updatedAt: string;
  progress: string;
  makePdf: boolean;
  researchPack?: ResearchPack;
  imagePrompt?: string;
  pngFile?: string;
  pngUrl?: string;
  pdfFile?: string;
  pdfUrl?: string;
  error?: string;
  fallbackPrompt?: string;
};
