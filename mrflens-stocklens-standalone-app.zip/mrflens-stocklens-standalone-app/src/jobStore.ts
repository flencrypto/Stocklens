import crypto from "node:crypto";
import path from "node:path";
import { OUTPUT_DIR } from "./config.js";
import { createPdfFromPng } from "./pdf.js";
import { buildImagePrompt } from "./prompts.js";
import type { StockLensJob } from "./schemas.js";
import { buildResearchPack, generateOnePagerImage } from "./stockLens.js";

const jobs = new Map<string, StockLensJob>();

function now() {
  return new Date().toISOString();
}

export function createJob(query: string, makePdf: boolean) {
  const id = crypto.randomUUID();
  const job: StockLensJob = {
    id,
    status: "queued",
    query,
    makePdf,
    createdAt: now(),
    updatedAt: now(),
    progress: "Queued",
  };

  jobs.set(id, job);

  // Fire-and-track. For production, replace this with a durable queue.
  void processJob(id);

  return job;
}

export function getJob(id: string) {
  return jobs.get(id);
}

export function listJobs() {
  return Array.from(jobs.values()).sort((a, b) => b.createdAt.localeCompare(a.createdAt));
}

function patchJob(id: string, patch: Partial<StockLensJob>) {
  const job = jobs.get(id);
  if (!job) return;
  jobs.set(id, {
    ...job,
    ...patch,
    updatedAt: now(),
  });
}

async function processJob(id: string) {
  const job = jobs.get(id);
  if (!job) return;

  let imagePrompt = "";

  try {
    patchJob(id, {
      status: "running",
      progress: "Retrieving and cross-checking current sources",
    });

    const researchPack = await buildResearchPack(job.query);

    patchJob(id, {
      progress: "Building the Stock-LENS image prompt",
      researchPack,
    });

    imagePrompt = buildImagePrompt(researchPack);

    patchJob(id, {
      progress: "Generating the A4 portrait PNG with the image model",
      imagePrompt,
    });

    const image = await generateOnePagerImage(researchPack, imagePrompt);

    let pdfFile: string | undefined;
    let pdfUrl: string | undefined;

    if (job.makePdf) {
      patchJob(id, { progress: "Creating PDF wrapper" });
      pdfFile = image.pngFile.replace(/\.png$/i, ".pdf");
      const pdfPath = path.join(OUTPUT_DIR, pdfFile);
      await createPdfFromPng(image.pngPath, pdfPath);
      pdfUrl = `/outputs/${pdfFile}`;
    }

    patchJob(id, {
      status: "complete",
      progress: "Complete",
      researchPack,
      imagePrompt,
      pngFile: image.pngFile,
      pngUrl: image.pngUrl,
      pdfFile,
      pdfUrl,
    });
  } catch (error) {
    const message = error instanceof Error ? error.message : String(error);
    patchJob(id, {
      status: "failed",
      progress: "Failed",
      error: message,
      fallbackPrompt: imagePrompt,
    });
  }
}
