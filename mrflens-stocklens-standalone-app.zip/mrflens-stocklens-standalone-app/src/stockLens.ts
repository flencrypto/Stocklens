import fs from "node:fs/promises";
import path from "node:path";
import { zodTextFormat } from "openai/helpers/zod";
import { config, OUTPUT_DIR } from "./config.js";
import { openai } from "./openaiClient.js";
import { buildImagePrompt, buildResearchInstruction, STOCK_LENS_SYSTEM } from "./prompts.js";
import { createPdfFromPng } from "./pdf.js";
import { ResearchPackSchema, type ResearchPack } from "./schemas.js";
import { normalizeTicker, safeFileStem, todayStamp, validateResearchPackOrThrow } from "./sourceUtils.js";

export type StockLensResult = {
  researchPack: ResearchPack;
  imagePrompt: string;
  pngFile: string;
  pngUrl: string;
  pdfFile?: string;
  pdfUrl?: string;
};

export async function buildResearchPack(query: string): Promise<ResearchPack> {
  const response = await openai.responses.parse({
    model: config.reasoningModel,
    reasoning: { effort: config.reasoningEffort as any },
    tools: [
      {
        type: "web_search",
        return_token_budget: "unlimited",
        external_web_access: true,
      } as any,
    ],
    tool_choice: "required" as any,
    include: ["web_search_call.action.sources"] as any,
    input: [
      { role: "system", content: STOCK_LENS_SYSTEM },
      { role: "user", content: buildResearchInstruction(query) },
    ],
    text: {
      format: zodTextFormat(ResearchPackSchema, "stock_lens_research_pack"),
    },
  } as any);

  const pack = response.output_parsed;
  if (!pack) {
    throw new Error("OpenAI returned no structured research pack.");
  }

  validateResearchPackOrThrow(pack);
  return pack;
}

export async function generateOnePagerImage(pack: ResearchPack, imagePrompt: string) {
  await fs.mkdir(OUTPUT_DIR, { recursive: true });

  const ticker = normalizeTicker(pack.ticker || "STOCK");
  const fileStem = safeFileStem(`${ticker}_MrFLENS_StockLENS_One_Page_DeepDive_${todayStamp()}`);
  const pngFile = `${fileStem}.png`;
  const pngPath = path.join(OUTPUT_DIR, pngFile);

  const result = await openai.images.generate({
    model: config.imageModel,
    prompt: imagePrompt,
    size: config.imageSize,
    quality: config.imageQuality,
    output_format: "png",
    n: 1,
  } as any);

  const b64 = result.data?.[0]?.b64_json;
  if (!b64) {
    throw new Error("Image generation returned no base64 image data.");
  }

  await fs.writeFile(pngPath, Buffer.from(b64, "base64"));
  return {
    pngFile,
    pngPath,
    pngUrl: `/outputs/${pngFile}`,
  };
}

export async function runStockLensOnePager(query: string, makePdf: boolean): Promise<StockLensResult> {
  const researchPack = await buildResearchPack(query);
  const imagePrompt = buildImagePrompt(researchPack);
  const image = await generateOnePagerImage(researchPack, imagePrompt);

  let pdfFile: string | undefined;
  let pdfUrl: string | undefined;

  if (makePdf) {
    pdfFile = image.pngFile.replace(/\.png$/i, ".pdf");
    const pdfPath = path.join(OUTPUT_DIR, pdfFile);
    await createPdfFromPng(image.pngPath, pdfPath);
    pdfUrl = `/outputs/${pdfFile}`;
  }

  return {
    researchPack,
    imagePrompt,
    pngFile: image.pngFile,
    pngUrl: image.pngUrl,
    pdfFile,
    pdfUrl,
  };
}
