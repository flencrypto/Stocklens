import type { ResearchPack } from "./schemas.js";

export function uniq<T>(items: T[]): T[] {
  return Array.from(new Set(items));
}

export function normalizeTicker(ticker: string) {
  return ticker.replace(/[^A-Za-z0-9.-]/g, "").toUpperCase();
}

export function todayStamp() {
  return new Date().toISOString().slice(0, 10);
}

export function safeFileStem(value: string) {
  return value.replace(/[^A-Za-z0-9._-]+/g, "_").replace(/^_+|_+$/g, "");
}

export function validateResearchPackOrThrow(pack: ResearchPack) {
  const sourceNames = uniq(pack.sources.map((s) => s.name).filter(Boolean));
  if (sourceNames.length < 3) {
    throw new Error("Research pack has fewer than 3 distinct sources. Current cross-checking is insufficient.");
  }

  const metricsWithoutSources = pack.heroMetrics.filter((m) => !m.sourceNames?.length);
  if (metricsWithoutSources.length) {
    throw new Error(
      `Research pack contains hero metrics without source names: ${metricsWithoutSources
        .map((m) => m.label)
        .join(", ")}`
    );
  }

  const forbidden = [
    "buy",
    "strong buy",
    "sell",
    "hold recommendation",
    "guaranteed",
    "certain to",
  ];
  const joined = JSON.stringify(pack).toLowerCase();
  const bad = forbidden.find((word) => joined.includes(word));
  if (bad) {
    throw new Error(`Research pack contains non-compliant or overconfident wording: "${bad}".`);
  }
}

export function extractLooseSourcesFromResponse(response: unknown) {
  const sources: Array<{ name?: string; title?: string; url?: string }> = [];

  function walk(value: unknown) {
    if (!value || typeof value !== "object") return;
    if (Array.isArray(value)) {
      for (const item of value) walk(item);
      return;
    }

    const obj = value as Record<string, unknown>;
    const url = typeof obj.url === "string" ? obj.url : undefined;
    const title = typeof obj.title === "string" ? obj.title : undefined;
    const name = typeof obj.name === "string" ? obj.name : undefined;
    if (url || title || name) sources.push({ name, title, url });

    for (const v of Object.values(obj)) walk(v);
  }

  walk(response);
  return sources;
}
