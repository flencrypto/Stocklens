# Mr.FLENS Stock-LENS Standalone App

A standalone local web app that turns a ticker/company + horizon into a Mr.FLENS Stock-LENS one-page PNG using the OpenAI API.

The app follows this workflow:

1. Resolve the user request into a company/ticker/horizon.
2. Use the Responses API with hosted web search to retrieve current source-backed data.
3. Build a structured research pack.
4. Build the mandatory rich GPT Image prompt.
5. Generate the final A4 portrait Stock-LENS PNG using `gpt-image-2`.
6. Optionally create a one-page PDF wrapper around the generated PNG.

## Install

```bash
npm install
cp .env.example .env
```

Add your key to `.env`:

```bash
OPENAI_API_KEY=sk-your-key-here
```

The code also accepts `OPEN_AI_API_KEY` as an alias, but `OPENAI_API_KEY` is the normal OpenAI SDK convention.

## Run

```bash
npm run dev
```

Open:

```text
http://localhost:8787
```

## Build

```bash
npm run build
npm start
```

## API

### Start a one-pager job

```bash
curl -X POST http://localhost:8787/api/jobs \
  -H "Content-Type: application/json" \
  -d '{"query":"PL 3-5 yr","makePdf":true}'
```

### Poll job

```bash
curl http://localhost:8787/api/jobs/<jobId>
```

### Health

```bash
curl http://localhost:8787/api/health
```

## Notes

- Keep the OpenAI API key server-side. Never put it in the browser.
- For production, replace the in-memory job store with Redis, Postgres, S3/R2 object storage, and a real queue.
- For institutional use, consider adding dedicated market-data providers for price, market cap, consensus, ownership, and short-interest checks. The included version uses OpenAI hosted web search to gather and cross-check public sources.
- GPT Image models may require organization verification on your OpenAI account.
- Image models can still struggle with dense text rendering. The app preserves the full fallback prompt so you can regenerate or revise when needed.
