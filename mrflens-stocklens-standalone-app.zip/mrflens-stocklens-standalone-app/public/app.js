const form = document.getElementById("job-form");
const queryInput = document.getElementById("query");
const makePdfInput = document.getElementById("makePdf");

const statusPanel = document.getElementById("status-panel");
const statusTitle = document.getElementById("status-title");
const statusDetail = document.getElementById("status-detail");
const spinner = document.getElementById("spinner");

const resultPanel = document.getElementById("result-panel");
const onepagerImg = document.getElementById("onepager-img");
const downloadLinks = document.getElementById("download-links");
const researchJson = document.getElementById("research-json");
const promptText = document.getElementById("prompt-text");

const errorPanel = document.getElementById("error-panel");
const errorTitle = document.getElementById("error-title");
const errorDetail = document.getElementById("error-detail");
const fallbackPrompt = document.getElementById("fallback-prompt");

let pollTimer = null;

function show(el) {
  el.classList.remove("hidden");
}

function hide(el) {
  el.classList.add("hidden");
}

function setStatus(title, detail, spinning = true) {
  show(statusPanel);
  statusTitle.textContent = title;
  statusDetail.textContent = detail || "";
  spinner.style.display = spinning ? "block" : "none";
}

function resetPanels() {
  hide(resultPanel);
  hide(errorPanel);
  downloadLinks.innerHTML = "";
  onepagerImg.removeAttribute("src");
  researchJson.textContent = "";
  promptText.value = "";
  fallbackPrompt.value = "";
}

async function createJob(query, makePdf) {
  const res = await fetch("/api/jobs", {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify({ query, makePdf }),
  });

  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${res.status}`);
  }

  return res.json();
}

async function fetchJob(jobId) {
  const res = await fetch(`/api/jobs/${jobId}`);
  if (!res.ok) {
    const body = await res.json().catch(() => ({}));
    throw new Error(body.error || `HTTP ${res.status}`);
  }
  return res.json();
}

function renderComplete(job) {
  setStatus("Complete", "Stock-LENS one-pager generated.", false);

  if (job.pngUrl) {
    onepagerImg.src = job.pngUrl;
    const png = document.createElement("a");
    png.href = job.pngUrl;
    png.download = job.pngFile || "stock-lens-one-pager.png";
    png.textContent = "Download PNG";
    downloadLinks.appendChild(png);
  }

  if (job.pdfUrl) {
    const pdf = document.createElement("a");
    pdf.href = job.pdfUrl;
    pdf.download = job.pdfFile || "stock-lens-one-pager.pdf";
    pdf.textContent = "Download PDF";
    downloadLinks.appendChild(pdf);
  }

  researchJson.textContent = JSON.stringify(job.researchPack || {}, null, 2);
  promptText.value = job.imagePrompt || "";
  show(resultPanel);
}

function renderFailed(job) {
  hide(statusPanel);
  show(errorPanel);
  errorTitle.textContent = "Image/research generation failed";
  errorDetail.textContent = job.error || "Unknown error";
  fallbackPrompt.value = job.fallbackPrompt || job.imagePrompt || "";
}

function startPolling(jobId) {
  if (pollTimer) clearInterval(pollTimer);

  pollTimer = setInterval(async () => {
    try {
      const job = await fetchJob(jobId);
      setStatus(job.status, job.progress || "Working", job.status !== "complete" && job.status !== "failed");

      if (job.status === "complete") {
        clearInterval(pollTimer);
        renderComplete(job);
      }

      if (job.status === "failed") {
        clearInterval(pollTimer);
        renderFailed(job);
      }
    } catch (err) {
      clearInterval(pollTimer);
      hide(statusPanel);
      show(errorPanel);
      errorTitle.textContent = "Could not poll job";
      errorDetail.textContent = err instanceof Error ? err.message : String(err);
    }
  }, 2500);
}

form.addEventListener("submit", async (event) => {
  event.preventDefault();
  resetPanels();

  const query = queryInput.value.trim();
  if (!query) return;

  setStatus("Queued", "Submitting request...", true);

  try {
    const { jobId } = await createJob(query, makePdfInput.checked);
    setStatus("Running", "Retrieving current sources and generating the image.", true);
    startPolling(jobId);
  } catch (err) {
    hide(statusPanel);
    show(errorPanel);
    errorTitle.textContent = "Could not create job";
    errorDetail.textContent = err instanceof Error ? err.message : String(err);
  }
});
